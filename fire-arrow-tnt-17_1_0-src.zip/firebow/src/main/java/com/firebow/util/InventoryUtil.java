package com.firebow.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.function.Predicate;

/**
 * Hotbar search — pattern từ BOOST-FPS.
 * Dùng Predicate thay vì hardcode item để linh hoạt.
 */
public final class InventoryUtil {
    private InventoryUtil() {}

    /** Tìm slot đầu tiên trong hotbar thỏa predicate. */
    public static SearchResult findInHotbar(Predicate<ItemStack> predicate) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return SearchResult.MISSING;

        var inv = client.player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv.getStack(i);
            if (!stack.isEmpty() && predicate.test(stack)) {
                return SearchResult.of(i);
            }
        }
        return SearchResult.MISSING;
    }

    /** Shortcut tìm theo item cụ thể. */
    public static SearchResult findItem(Item item) {
        return findInHotbar(stack -> stack.getItem() == item);
    }

    /** Tìm theo nhiều item, trả slot đầu tiên match. */
    public static SearchResult findAny(Item... items) {
        return findInHotbar(stack -> {
            for (Item item : items) {
                if (stack.getItem() == item) return true;
            }
            return false;
        });
    }
}
