package com.firebow.mixin;

import com.firebow.util.RotationUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Movement fix khi rotate — port từ BOOST-FPS.
 *
 * Khi RotationUtil có pending rotation, chỉnh forward/sideways input
 * theo yaw mới → Grim thấy movement vector nhất quán với rotation trong packet.
 * Không có fix này → "impossible movement" flag khi vừa đi vừa bắn.
 */
@Environment(EnvType.CLIENT)
@Mixin(KeyboardInput.class)
public class KeyboardInputMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void firebow$fixInput(CallbackInfo ci) {
        if (!RotationUtil.hasPendingRotation()) return;

        Input self = (Input)(Object) this;
        float[] rot = RotationUtil.getPendingRot();
        if (rot == null) return;

        float yawDelta = rot[0]; // yaw đang pending (absolute degrees)

        // Lấy movement input hiện tại
        float forward  = self.movementForward;
        float sideways = self.movementSideways;
        if (forward == 0 && sideways == 0) return;

        // Rotate input vector theo yaw delta (giống BOOST-FPS fixKeyboardInput)
        float yawRad = (float) Math.toRadians(yawDelta);
        float cos = (float) Math.cos(-yawRad);
        float sin = (float) Math.sin(-yawRad);

        self.movementForward   = forward * cos - sideways * sin;
        self.movementSideways  = forward * sin + sideways * cos;
    }
}
