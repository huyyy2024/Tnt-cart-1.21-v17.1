package com.firebow.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;

/**
 * ClientTickMixin v2 — KHÔNG gọi onClientTick nữa.
 *
 * onClientTick được gọi duy nhất từ FireBowClient
 * qua ClientTickEvents.END_CLIENT_TICK.
 *
 * Lý do: gọi từ 2 nơi (Mixin + Event) → double tick,
 * cart delay bị giảm đôi, timing sai.
 *
 * Mixin này giữ lại nhưng rỗng để dễ mở rộng sau.
 */
@Environment(EnvType.CLIENT)
@Mixin(MinecraftClient.class)
public class ClientTickMixin {
    // Intentionally empty — xem FireBowClient.java
}
