package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.target.PlacementTarget;
import com.firebow.util.InteractionUtil;
import com.firebow.util.PlacementCalc;
import com.firebow.util.PingUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(PersistentProjectileEntity.class)
public class FireArrowMixin {

    @Unique private int firebow$age = 0;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        firebow$age++;
        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled()) return;

        PersistentProjectileEntity self = (PersistentProjectileEntity)(Object) this;
        MinecraftClient mc = MinecraftClient.getInstance();

        if (!isOwnArrow(self, mc)) return;
        if (!self.isOnFire()) return;
        if (self.isOnGround()) return;
        if (mc.player == null || mc.interactionManager == null) return;
        if (self.getVelocity().lengthSquared() < 0.0001) return;
        if (firebow$age > 40) return;

        int entityId = self.getId();
        if (rt.isDuplicateArrow(entityId)) return;

        Vec3d pos  = self.getPos();
        Vec3d vel  = self.getVelocity();
        World world = self.getWorld();

        // Lấy precomputed từ bow release (ưu tiên), fallback về real-time predict
        BlockPos precomputed = rt.getAndClearPrecomputed();
        BlockPos railPos;

        if (precomputed != null
                && !rt.wasRecentlyPlaced(precomputed)
                && InteractionUtil.inReach(mc.player, precomputed)
                && mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(precomputed)) >= 1.0) {
            railPos = precomputed;
        } else {
            // Fallback: predict từ velocity arrow hiện tại
            if (estimateTicksToLand(pos, vel) > 25) return; // quá xa
            railPos = PlacementCalc.predictLandingRailPos(world, pos, vel);
            if (railPos == null) return;
            if (!InteractionUtil.inReach(mc.player, railPos)) return;
            if (rt.wasRecentlyPlaced(railPos)) return;
            if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(railPos)) < 1.0) return;
        }

        // Kiểm tra inventory
        PlacementTarget target = PlacementTarget.tryCreate(railPos);
        if (target == null) return;

        // Phase 1: schedule rail placement (2-tick pattern)
        // KHÔNG interact trực tiếp — chuẩn bị rotation + pending
        rt.scheduleRailPlacement(mc, entityId, railPos, target.railSlot.slot);

        // Schedule cart sau khi rail placed
        long ping = PingUtil.getPingMs(mc);
        rt.scheduleCartPlacement(railPos, ping);
    }

    /**
     * Ước lượng số tick còn lại đến khi tên chạm đất.
     * Dùng để lọc: tên quá xa (>25 tick) thì chưa cần xử lý.
     */
    private int estimateTicksToLand(Vec3d pos, Vec3d vel) {
        double x = pos.x, y = pos.y, z = pos.z;
        double vx = vel.x, vy = vel.y, vz = vel.z;
        for (int i = 0; i < 60; i++) {
            vy -= 0.05;
            vx *= 0.99; vy *= 0.99; vz *= 0.99;
            x += vx; y += vy; z += vz;
            // Heuristic: tên đang đi xuống và gần mặt đất
            if (vy < 0 && y < pos.y - 0.5) return i;
        }
        return 60;
    }

    private boolean isOwnArrow(PersistentProjectileEntity a, MinecraftClient mc) {
        if (mc.player == null) return false;
        Entity owner = a.getOwner();
        return owner != null && owner.getId() == mc.player.getId();
    }
}
